# drcodecover

A wrapper around Sentry for easy initialization.

## Installation

```bash
pip install drcodecover

init_drcode({
'protocol': 'http',
'public_key': '4ee0c9a55a3745ab839927b819b73037',
'host': '13.202.160.252',
'port': 8000,
'project_id': '1',
'traces_sample_rate': 1.0,
'profiles_sample_rate': 1.0
})
```
